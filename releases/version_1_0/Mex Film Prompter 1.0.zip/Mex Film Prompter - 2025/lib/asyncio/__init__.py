import sys

# Import modules explicitly
from . import base_events
from . import coroutines
from . import events
from . import exceptions
from . import futures
from . import locks
from . import protocols
from . import runners
from . import queues
from . import streams
from . import subprocess
from . import tasks
from . import taskgroups
from . import timeouts
from . import threads
from . import transports

# Import everything from them (optional, if you want symbols directly available)
from .base_events import *
from .coroutines import *
from .events import *
from .exceptions import *
from .futures import *
from .locks import *
from .protocols import *
from .runners import *
from .queues import *
from .streams import *
from .subprocess import *
from .tasks import *
from .taskgroups import *
from .timeouts import *
from .threads import *
from .transports import *

__all__ = (
    base_events.__all__ +
    coroutines.__all__ +
    events.__all__ +
    exceptions.__all__ +
    futures.__all__ +
    locks.__all__ +
    protocols.__all__ +
    runners.__all__ +
    queues.__all__ +
    streams.__all__ +
    subprocess.__all__ +
    tasks.__all__ +
    taskgroups.__all__ +
    threads.__all__ +
    timeouts.__all__ +
    transports.__all__
)

# Platform-specific
if sys.platform == 'win32':  # pragma: no cover
    from . import windows_events
    from .windows_events import *
    __all__ += windows_events.__all__
else:
    from . import unix_events
    from .unix_events import *  # pragma: no cover
    __all__ += unix_events.__all__
